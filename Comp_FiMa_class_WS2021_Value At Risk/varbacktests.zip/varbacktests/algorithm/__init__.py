from varbacktests.algorithm.tl import TL
from varbacktests.algorithm.bin import Bin
from varbacktests.algorithm.pof import Pof
from varbacktests.algorithm.tuff import Tuff
from varbacktests.algorithm.cci import CCI
from varbacktests.algorithm.cc import CC
from varbacktests.algorithm.tbfi import Tbfi
from varbacktests.algorithm.tbf import Tbf
